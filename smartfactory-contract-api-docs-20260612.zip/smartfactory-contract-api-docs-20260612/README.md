# SmartFactory Contract/API Docs Package

Generated: 2026-06-12 Asia/Seoul

Included:

- `docs/contracts/ai-server-api.md` — human-readable AI Server API contract
- `docs/contracts/ai-server-openapi.json` — generated OpenAPI 3.1 snapshot from the FastAPI app
- `docs/contracts/vision-event.schema.json` — `VisionEvent v1` payload schema
- `docs/contracts/lift-roi-evidence.schema.json` — `LiftRoiEvidence v1` payload schema
- `docs/contracts/fixtures/` — valid/invalid contract fixtures
- `scripts/validate_contracts.py` — local fixture/schema validation script
- `services/ai-server/README.md` — AI Server endpoint/runtime summary

Validation used before packaging:

- `./scripts/test_ai_server.sh -q` -> 85 passed, 1 warning
- `python3 scripts/validate_deployment_assets.py` -> Deployment assets validated.
