# SmartFactory AI Server API Contract v1

- Status: Draft contract for MVP1 implementation planning; AI Server endpoints below reflect the 2026-06-12 local implementation.
- Date: 2026-06-12
- Goal: make AI Server, Main Server/WMS-lite, and GUI work mergeable by API contract before implementation.
- Canonical payload schemas: `docs/contracts/vision-event.schema.json`, `docs/contracts/lift-roi-evidence.schema.json`
- Generated OpenAPI snapshot: `docs/contracts/ai-server-openapi.json`

## Principles

1. **API first**: implementation lanes depend on this contract, not on each other's internal modules.
2. **Evidence only**: AI Server emits `VisionEvent`; WMS-lite owns final task, slot, item, robot, and exception state transitions.
3. **Versioned contract**: all MVP1 endpoints use `/api/v1`; events include `schema_version: vision-event.v1`.
4. **Strict source IDs**: MVP1 camera sources are `global_cam_01`, `tb3_1_picam`, `tb3_2_picam`.
5. **No depth dependency**: MVP1 has no robot-mounted depth camera; `depth_median_m` must be `null`.
6. **Contract-first merge**: schema and endpoint changes merge before AI/WMS/GUI implementation branches.
7. **Strict schema evolution**: because `additionalProperties: false`, any additive field must first be added to the schema and fixtures, then merged across lanes before any service emits it.

## Common response objects

### Error object

AI Server error responses use one common JSON envelope. The same `X-Request-ID`
value is also returned as an HTTP response header.

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "VisionEvent failed schema validation",
    "details": ["robot_id is required"],
    "request_id": "req_20260609_0001"
  }
}
```

Current AI Server error codes include `BAD_REQUEST`, `VALIDATION_ERROR`,
`CONTRACT_VALIDATION_FAILED`, `SERVICE_UNAVAILABLE`, and generic `HTTP_ERROR`
for unmapped status codes.

Recommended status codes:

| Code | Meaning |
| ---: | --- |
| 200 | successful read or idempotent duplicate ingest |
| 202 | event accepted for WMS processing |
| 400 | malformed request, bad query parameter, or invalid multipart payload |
| 404 | requested source/event not found |
| 409 | contract/schema version conflict that cannot be processed |
| 422 | JSON schema or policy validation error |
| 503 | source/model unavailable |

## AI Server endpoints

MVP1 keeps two evidence layers separate:

- `VisionEvent v1` is the lightweight event stream for marker/person/obstacle/item candidates.
- `LiftRoiEvidence v1` is the richer ROI/count/verification summary for lift load pickup/dropoff decisions.

Do **not** force lift count, mask, or stability fields into `VisionEvent v1`.
WMS/Main may later translate a confirmed `LiftRoiEvidence` result into its own
task/inventory transition, but AI Server remains evidence-only.

### `GET /api/v1/health`

Purpose: service liveness/readiness. It must not require all cameras to be online.

Response `200`:

```json
{
  "service": "ai-server",
  "status": "ok",
  "service_version": "0.1.0",
  "contract_version": "vision-event.v1",
  "model_status": "loaded",
  "models": {
    "marker": {
      "status": "loaded",
      "name": "opencv-marker-detector"
    },
    "lift_roi": {
      "status": "disabled | loaded | error",
      "task": "segment | detect",
      "path_configured": false,
      "device": "cpu"
    }
  },
  "source_summary": {
    "configured": 3,
    "online": 2,
    "stale": 1,
    "disabled": 0,
    "offline": 0
  },
  "event_retention": {
    "maxlen": 200,
    "size": 0
  }
}
```

`model_status` is retained as a backward-compatible marker/base-service status.
Use `models.marker` and `models.lift_roi` for model-specific readiness.
`models.lift_roi.status=disabled` means `/api/v1/lift-roi/evaluate-image` will
fail closed with HTTP `503` until `VISION_MODEL_PATH` is configured.

### `GET /api/v1/sources`

Purpose: exact source list and health for AI/WMS/GUI integration.

Response `200`:

```json
{
  "sources": [
    {
      "source": "global_cam_01",
      "kind": "global_rgb",
      "robot_id": null,
      "enabled": true,
      "status": "online | stale | offline | disabled",
      "frame_id": "global_camera_frame",
      "last_frame_at": "2026-06-09T15:30:00+09:00",
      "last_frame_age_s": 0.25,
      "last_event_at": "2026-06-09T15:30:00+09:00",
      "last_event_kind": "CONFIRMED",
      "last_event_id": "11111111-1111-4111-8111-111111111111",
      "last_marker_id": "ARUCO_4X4_50_7",
      "frame_count": 42,
      "event_count": 3,
      "target_fps": 10,
      "notes": "overview/slot/zone evidence",
      "ros_topic": "/global_camera/image_raw"
    },
    {
      "source": "tb3_1_picam",
      "kind": "robot_pi_camera",
      "robot_id": "tb3_1",
      "enabled": true,
      "status": "online",
      "frame_id": "tb3_1_pi_camera_optical_frame",
      "last_frame_at": "2026-06-09T15:30:00+09:00",
      "last_frame_age_s": 0.12,
      "last_event_at": null,
      "last_event_kind": null,
      "last_event_id": null,
      "last_marker_id": null,
      "frame_count": 10,
      "event_count": 0,
      "target_fps": 10,
      "notes": "front marker/dock/local item evidence",
      "ros_topic": "/tb3_1/pi_camera/image_raw"
    }
  ]
}
```

Source status is freshness-based. A configured source is `offline` until a
valid frame is decoded. After a frame, it is `online` until
`SOURCE_STALE_AFTER_S`, then `stale` until `SOURCE_OFFLINE_AFTER_S`, then
`offline` again. `last_event_*` fields update only when a detection event is
generated; marker-free frames still refresh `last_frame_at` and `frame_count`.

### `GET /api/v1/detections/latest?source=global_cam_01&limit=10`

Purpose: debug/latest detection feed from AI Server. WMS state should still come from WMS ingest, not direct GUI coupling.

Query parameters:

| Name | Required | Description |
| --- | --- | --- |
| `source` | no | one of `global_cam_01`, `tb3_1_picam`, `tb3_2_picam`; omit for all |
| `limit` | no | integer 1-50, default 10 |

Response `200`:

```json
{
  "generated_at": "2026-06-09T15:30:03+09:00",
  "events": [
    { "schema_version": "vision-event.v1", "event_id": "11111111-1111-4111-8111-111111111111" }
  ]
}
```

`events[]` items must be full `VisionEvent` objects conforming to `vision-event.schema.json`; shortened above only for readability.

### `GET /api/v1/metrics`

Purpose: local AI Server observability snapshot for development, operations, and
contract smoke tests. This is not a WMS state API.

Response `200`:

```json
{
  "generated_at": "2026-06-12T14:30:03+09:00",
  "metrics": {
    "http": {
      "request_total": 3,
      "status_total": {"200": 3},
      "route_total": [
        {"method": "GET", "path": "/api/v1/health", "count": 1}
      ]
    },
    "detect_image": {"calls_total": 1, "events_total": 1},
    "lift_roi": {
      "evaluations_total": 1,
      "verification_total": {"CONFIRMED": 1}
    }
  },
  "event_store": {"maxlen": 200, "size": 1}
}
```

### `POST /api/v1/detect/image`

Purpose: offline fixture/manual image test. This is for development and contract tests, not the main live video path.

Request: `multipart/form-data`

| Field | Required | Description |
| --- | --- | --- |
| `source` | yes | source ID to evaluate as |
| `image` | yes | image file |
| `emit` | no | `false` default; if `true`, AI Server may POST accepted events to Main Server |
| `pose_profile` | no | named profile from `ARUCO_POSE_PROFILES_PATH`; cannot be combined with manual calibration fields |
| `marker_size_m` | no | positive marker size in meters; required with camera intrinsics to compute optional ArUco pose |
| `camera_fx` | no | camera focal length x in pixels; required for optional ArUco pose |
| `camera_fy` | no | camera focal length y in pixels; required for optional ArUco pose |
| `camera_cx` | no | camera principal point x in pixels; required for optional ArUco pose |
| `camera_cy` | no | camera principal point y in pixels; required for optional ArUco pose |
| `camera_dist_coeffs` | no | optional comma-separated OpenCV distortion coefficients for optional ArUco pose |

When `pose_profile` is provided, the server loads marker size and camera
intrinsics from `ARUCO_POSE_PROFILES_PATH` (default:
`config/perception/aruco_pose_profiles.example.json`). Profile source/marker ID
must match the request/detection before pose is emitted; otherwise the marker
event remains valid but `pose_estimate` stays `null`.

When all manual marker/camera calibration fields are provided, ArUco marker
events may also include `pose_estimate.method=ARUCO_POSE`. In MVP1 this is
camera-frame planar docking evidence: `pose_estimate.x` is lateral offset in
meters, `pose_estimate.y` is forward marker distance in meters, and
`pose_estimate.yaw` is marker face yaw in radians. If profile/manual calibration
fields are omitted, `pose_estimate` remains `null`. Partial calibration input or
combining `pose_profile` with manual calibration fields is rejected with HTTP
`400` so the server does not emit ambiguous pose estimates.

Emission is disabled by default at runtime. `emit=true` only requests emission;
the server attempts outbound WMS ingest only when `WMS_EMIT_ENABLED=true`.

Response `200`:

```json
{
  "source": "tb3_1_picam",
  "emitted": false,
  "emit_disabled": true,
  "emit_results": [],
  "events": [
    { "schema_version": "vision-event.v1", "event_id": "22222222-2222-4222-8222-222222222222" }
  ]
}
```

`events[]` items must be full `VisionEvent` objects.

`emitted` is an outcome flag, not an echo of the request flag. It is `true`
only when all of the following are true:

- request field `emit=true`
- runtime setting `WMS_EMIT_ENABLED=true`
- at least one event was generated
- every attempted WMS ingest returned HTTP `200` or `202`

Otherwise `emitted` is `false`. WMS ingest failure must not fail this endpoint;
the local detection result remains useful evidence.

When emission is enabled and attempted, `emit_results[]` contains one item per
event:

```json
{
  "event_id": "22222222-2222-4222-8222-222222222222",
  "attempted": true,
  "ok": true,
  "status_code": 202,
  "error": null,
  "response": {
    "accepted": true,
    "duplicate": false,
    "wms_processing_status": "queued"
  }
}
```

`response` is parsed JSON when the WMS response body is JSON; otherwise it is
`null`. For transport errors, timeouts, and non-2xx responses, `ok` is `false`
and `error` contains a short diagnostic string.

### `POST /api/v1/lift-roi/evaluate`

Purpose: evaluate caller-provided detector/segmenter candidates against a
configured lift or target-slot ROI and return a contract-valid
`LiftRoiEvidence v1` payload. This endpoint is implemented as the stable seam
for synthetic tests, offline fixtures, and future model providers.

Canonical response schema: `docs/contracts/lift-roi-evidence.schema.json`.

Request shape:

```json
{
  "source": "tb3_1_picam",
  "operation": "PICKUP",
  "task_id": "TASK-IN-0001",
  "image": { "width": 640, "height": 480 },
  "roi": {
    "roi_id": "TB3_1_LIFT_ROI",
    "kind": "LIFT",
    "polygon_xy": [[220, 180], [420, 180], [440, 360], [200, 360]]
  },
  "expected_count": 2,
  "stable_frames": 5,
  "count_stable": true,
  "lift_sensor": {
    "lift_up": true,
    "lift_down_complete": null,
    "backoff_complete": null
  },
  "candidates": [
    {
      "class_name": "box",
      "bbox_xyxy": [240, 210, 310, 290],
      "confidence": 0.91,
      "track_id": "box-1",
      "evidence_type": "bbox",
      "mask_area_px": null
    }
  ]
}
```

Response `200` is a full `LiftRoiEvidence v1` object. Example excerpt:

```json
{
  "schema_version": "lift-roi-evidence.v1",
  "evidence_id": "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
  "source": "tb3_1_picam",
  "robot_id": "tb3_1",
  "operation": "PICKUP",
  "expected_count": 2,
  "count_stable": true,
  "load": {
    "count": 2,
    "empty": false,
    "accepted_items": [
      {
        "class_name": "box",
        "bbox_xyxy": [240, 210, 310, 290],
        "confidence": 0.91,
        "evidence_type": "bbox",
        "center_inside_roi": true,
        "overlap_ratio": 0.98,
        "reason": "accepted"
      }
    ],
    "rejected_items": []
  },
  "dropped_item_count": 0,
  "verification": {
    "status": "CONFIRMED",
    "reason": "pickup_verified"
  }
}
```

Policy constraints validated by fixtures:

- source/robot mapping follows the same policy as `VisionEvent v1`.
- `load.count` must equal `accepted_items.length`.
- `load.empty` must match `load.count == 0`.
- accepted items must use `reason=accepted` and have `center_inside_roi=true`.
- confirmed pickup requires `expected_count`, matching count, stable count,
  `lift_up=true`, and `dropped_item_count=0`.
- confirmed dropoff requires `lift_down_complete=true` and `backoff_complete=true`.

This contract allows either bbox-only detection or instance segmentation:

- `evidence_type=bbox`: ROI overlap is computed from the bounding box area.
- `evidence_type=instance_mask`: ROI overlap is computed from the instance mask;
  the contract stores only summary fields such as `mask_area_px`, not raw masks.

### `POST /api/v1/lift-roi/evaluate-image`

Purpose: evaluate lift ROI evidence from an uploaded image using the configured
optional detector/segmenter runtime. Instance masks are preferred when the model
returns masks; bbox detections remain supported as fallback.

Request: `multipart/form-data`

| Field | Required | Description |
| --- | --- | --- |
| `source` | yes | source ID to evaluate as |
| `operation` | yes | `PICKUP`, `DROPOFF`, or `MONITOR` |
| `roi_json` | yes | JSON object with `roi_id`, `kind`, and `polygon_xy` |
| `image` | yes | image file |
| `task_id` | no | WMS task correlation ID or null |
| `expected_count` | no | non-negative expected load count |
| `stable_frames` | no | integer >= 1; default 1 |
| `count_stable` | no | boolean; default false |
| `lift_up` | no | nullable pickup lift sensor evidence |
| `lift_down_complete` | no | nullable dropoff lift-down evidence |
| `backoff_complete` | no | nullable robot backoff evidence |
| `dropped_item_count` | no | non-negative count; defaults from detector class when available |
| `policy_json` | no | optional policy object overriding load classes/confidence/overlap |

Runtime configuration:

```env
VISION_MODEL_PATH=/models/lift-load-seg.pt
VISION_MODEL_TASK=segment   # segment or detect
VISION_MODEL_CONF=0.5
VISION_MODEL_IOU=0.5
VISION_MODEL_IMGSZ=640
VISION_MODEL_DEVICE=cpu
```

Response `200`: full `LiftRoiEvidence v1`.

Response `503`: common error object when model path/package/runtime is
unavailable. This is fail-closed behavior; the endpoint must not return success
when the configured vision model cannot run.

## Main Server/WMS-lite endpoints consumed by AI Server

### `POST /api/v1/vision/events`

Purpose: authoritative ingest point for one AI evidence event.

Request body: one `VisionEvent` conforming to `docs/contracts/vision-event.schema.json` and policy validation in `scripts/validate_contracts.py`.

Response `202` accepted:

```json
{
  "accepted": true,
  "duplicate": false,
  "event_id": "11111111-1111-4111-8111-111111111111",
  "schema_version": "vision-event.v1",
  "wms_processing_status": "queued",
  "stored_at": "2026-06-09T15:30:04+09:00"
}
```

Response `200` duplicate/idempotent:

```json
{
  "accepted": true,
  "duplicate": true,
  "event_id": "11111111-1111-4111-8111-111111111111",
  "wms_processing_status": "already_seen"
}
```

Response `422` validation error uses the common error object.

Required WMS ingest behavior:

- Duplicate `event_id` must not create duplicate event-log rows.
- `STALE` events update source/zone freshness but must not directly complete or fail tasks.
- `CANDIDATE` events can be displayed and logged, but WMS policy decides whether to promote downstream state.
- `CONFIRMED` marker events may support slot/item/dock verification only when WMS policy and task context allow it.
- AI Server must never write directly to WMS DB.

### `POST /api/v1/vision/events/batch` optional, not MVP1 start gate

If implemented later, batch ingest must return per-item acceptance/rejection. Do not make AI Server depend on batch ingest for MVP1.

## GUI-facing Main Server endpoints

### `GET /api/v1/vision/events/latest?source=global_cam_01&limit=20`

Purpose: GUI Vision Detail and Robot Evidence summaries.

Response `200`:

```json
{
  "generated_at": "2026-06-09T15:30:05+09:00",
  "events": [
    { "schema_version": "vision-event.v1", "event_id": "11111111-1111-4111-8111-111111111111" }
  ]
}
```

### `GET /api/v1/vision/sources`

Purpose: GUI source health/staleness display derived from WMS ingest timestamps and AI source status.

Response `200`:

```json
{
  "sources": [
    {
      "source": "global_cam_01",
      "robot_id": null,
      "status": "online | stale | offline | disabled",
      "last_event_at": "2026-06-09T15:30:00+09:00",
      "last_frame_at": "2026-06-09T15:30:00+09:00"
    }
  ]
}
```

### `WS /ws/events`

Purpose: GUI receives WMS-normalized state/events. Raw AI evidence may appear as evidence entries, but GUI actions must target WMS/Main Server APIs.

Minimum message shape:

```json
{
  "type": "VISION_EVENT_INGESTED",
  "timestamp": "2026-06-09T15:30:05+09:00",
  "event_id": "11111111-1111-4111-8111-111111111111",
  "source": "global_cam_01",
  "summary": "Box candidate in STORAGE_A01_ROI",
  "wms_effect": "evidence_logged"
}
```

## Event-kind policy examples

| Kind | Required meaning | Example |
| --- | --- | --- |
| `CANDIDATE` | detected evidence, not enough alone for final WMS state | YOLO sees person/box for N frames |
| `CONFIRMED` | deterministic or policy-confirmed evidence | AprilTag/QR/ArUco marker decoded with marker_id |
| `CLEARED` | previously tracked evidence is no longer present | obstacle/person candidate has disappeared for policy window |
| `STALE` | source/ROI has no fresh frames/events | camera/source timeout; class must be `unknown`, hint `VISION_STALE` |

## Contract fixtures and validation

Fixture directory: `docs/contracts/fixtures/`

- Valid fixtures exist for `global_cam_01`, `tb3_1_picam`, `tb3_2_picam`, and `STALE`.
- Invalid fixtures cover wrong source/robot pairing, missing robot ID, non-null depth, missing marker ID for confirmed marker, and invalid bbox order.

Validation command:

```bash
python3 scripts/validate_contracts.py
```

## Merge gates

Before parallel implementation:

- [x] `docs/contracts/vision-event.schema.json` exists.
- [x] Example valid event fixtures exist for each source under `docs/contracts/fixtures/`.
- [x] Example invalid event fixtures cover wrong source/robot pairing and non-null depth.
- [x] Contract validation can run locally via `python3 scripts/validate_contracts.py`.
- [ ] AI Server, WMS ingest, and GUI lanes agree on event names and `/api/v1` paths.
- [ ] Git repository is initialized before multi-worker source implementation.

## Versioning rules

- Additive optional fields can stay in `vision-event.v1` only after the field is added to `vision-event.schema.json`, fixtures are updated, and all lanes tolerate it.
- Required field changes, enum removals/renames, or source ID changes require `vision-event.v2` and `/api/v2` planning.
- AI Server may update model versions without API changes if event semantics stay stable.
