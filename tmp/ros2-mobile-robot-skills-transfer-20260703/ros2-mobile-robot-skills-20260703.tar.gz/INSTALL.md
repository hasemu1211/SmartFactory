# Install — ROS2 Mobile Robot Skills Bundle

This archive contains two self-contained Codex/OMX-compatible skills:

- `ros2-engineering-handbook` — deep ROS 2 engineering reference and second-opinion handbook.
- `narrow-space-robot-navigation` — tight-clearance mobile robot navigation guidance.

## Install on another PC

Choose one skills directory used by your agent runtime:

```bash
mkdir -p ~/.codex/skills
cp -a ros2-engineering-handbook narrow-space-robot-navigation ~/.codex/skills/
```

or, for runtimes using the Agent Skills convention:

```bash
mkdir -p ~/.agents/skills
cp -a ros2-engineering-handbook narrow-space-robot-navigation ~/.agents/skills/
```

Restart the agent session after copying so skill discovery refreshes.

## Validate after install

If Codex skill validator is available, run:

```bash
python3 ~/.codex/skills/.system/skill-creator/scripts/quick_validate.py ~/.codex/skills/ros2-engineering-handbook
python3 ~/.codex/skills/.system/skill-creator/scripts/quick_validate.py ~/.codex/skills/narrow-space-robot-navigation
python3 -m py_compile ~/.codex/skills/ros2-engineering-handbook/scripts/*.py
```

If your runtime does not include the Codex validator, manually check that each skill has a `SKILL.md` whose YAML frontmatter contains only `name` and `description`.

## Usage intent

- Use `$ros2-engineering-handbook` when you want a deeper ROS2 engineering reference or second opinion.
- Use `$narrow-space-robot-navigation` for TurtleBot-class or small mobile robots driving through tight spaces, especially with lifts, forks, or payloads.

## Refreshing from upstream

The ROS2 handbook references were adapted from `dbwls99706/ros2-engineering-skills` commit `3706f65`. To refresh, compare upstream changes, update only the needed reference subset, preserve Apache-2.0 license/provenance, and rerun validation.
