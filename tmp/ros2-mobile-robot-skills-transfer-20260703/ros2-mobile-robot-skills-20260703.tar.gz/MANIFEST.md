# Manifest — ROS2 Mobile Robot Skills Bundle

## Bundle contents

- `INSTALL.md` — install and validation instructions for another PC.
- `MANIFEST.md` — this manifest.
- `ros2-engineering-handbook/` — Codex-compatible ROS2 engineering handbook skill.
- `narrow-space-robot-navigation/` — Codex-compatible narrow-space navigation skill.

## Provenance

- `ros2-engineering-handbook` imports a curated subset of `https://github.com/dbwls99706/ros2-engineering-skills` at commit `3706f65`.
- Upstream license is Apache-2.0 and is included at `ros2-engineering-handbook/LICENSE.upstream`.
- `narrow-space-robot-navigation` is generated guidance with Apache-2.0 license text included for portable personal distribution.

## Routing update

- `ros2-engineering-handbook` is a cross-domain ROS2 engineering reference layer. It should be used alongside narrower skills when correctness, safety, latency, deployment quality, field reliability, or architectural tradeoffs span multiple ROS2 domains.
- It should not be used for trivial single-file edits or routine package scaffolding when a narrower skill fully covers the task.

## File checksums

The following SHA256 list was generated at packaging time for all files in this archive except `MANIFEST.md` itself.

```text
7e2384a59bdd60e043ba2f794620e77b8f4dc018950f592508e05c15fbd262c8  ./INSTALL.md
4bd0f7b4747819a70780f0f85deb70c357c9b5ede5b1b79d60f105116f0673a0  ./narrow-space-robot-navigation/LICENSE
2c14399d556757b5053b93936d06229d0f6fb6dd19958ab0d54af0fc64c4b143  ./narrow-space-robot-navigation/PROVENANCE.md
b24eb99e7a4e6ac18b0da2554fd6b78ad1f42693f2b7738e612242a14a1c7984  ./narrow-space-robot-navigation/SKILL.md
b8e7b6514f7220bdfbef8d64b0f72aac7309eedfc4fb2d69c518b885e6ae32a6  ./narrow-space-robot-navigation/agents/openai.yaml
04c9272ce246340425967768efdc6dd1ed14d1c3063ad90f6bfb071fafeb7975  ./narrow-space-robot-navigation/references/compute-and-streaming-budget.md
583d6e7fd694044c0bb7f8029d8346ba9fa19a9d7738536e11f504d1344626b5  ./narrow-space-robot-navigation/references/footprint-and-safety.md
a5297e994256bec044ec02fc6b9ae862a92e2b0108af3737f261ff6ee88f02be  ./narrow-space-robot-navigation/references/localization-and-mapping.md
802fb0c6fd87465a550427d8de9e8ab17233fd7dfb74e4afc44f28dae78c022c  ./narrow-space-robot-navigation/references/nav2-tight-clearance.md
34675966e006e076b9e897544c7a673e1346d0574ec42f0d8fc5214e54204aee  ./narrow-space-robot-navigation/references/validation-protocol.md
4bd0f7b4747819a70780f0f85deb70c357c9b5ede5b1b79d60f105116f0673a0  ./ros2-engineering-handbook/LICENSE.upstream
e3f2b18f1867ce61e167f0b7407f52527f7fa1f37c863f5529054142ef719e88  ./ros2-engineering-handbook/PROVENANCE.md
9d0e104bd87af3f2cbaae7634048b61da6d157f6a78525311ee2ff0eddfad182  ./ros2-engineering-handbook/SKILL.md
297502f0498d6dbfaa7081697db375734c83d753036b1e7145bedfc801158de9  ./ros2-engineering-handbook/agents/openai.yaml
9afbf285961c3516a80a67a1b5c9e4059df2b4dcdaa64fa010098a5d44d613d0  ./ros2-engineering-handbook/references/communication.md
ab546d6b59a96fc3cb8ecbb38531acd74e5a9eb9d1168e9d5057b7aaa8fc1c1a  ./ros2-engineering-handbook/references/debugging.md
6270cf083840bdfdfb7f6e5ab815348ee1216373f073b38edae7aca08965c07e  ./ros2-engineering-handbook/references/deployment.md
7f06e528148d0ecbebcfccc2a6c02fe31ea5d027a8bc5e9684f6be9d44121e66  ./ros2-engineering-handbook/references/hardware-interface.md
ce77736a9af6325bae8985f1f7dc96658d9011aacf3d7ad04ab0023e1213ff8a  ./ros2-engineering-handbook/references/launch-system.md
8f251f76b28a8f73b42d5fb89c8f9689b59e86d6c01973718c2b62ceec61af3a  ./ros2-engineering-handbook/references/lifecycle-components.md
1193c31e3c98907f38a0c8de90e5b1cbbe925d5f5f2bfb4bbe9809e3ed0294d8  ./ros2-engineering-handbook/references/message-types.md
484892d8b7da957cc516ed4595556a29af8de25cf624ee4e135aa574cfb2f3c2  ./ros2-engineering-handbook/references/navigation.md
c51eabf33b1c8d510a4e62cd85cf89a5703619677fb5d90c25f5e141c4f3febd  ./ros2-engineering-handbook/references/nodes-executors.md
b596a0210ea4d7e5ebae89264ef719d54db593310005018c8f0cf3659b900fb0  ./ros2-engineering-handbook/references/perception.md
8cd04017341618aafe688885a7bc99789624ed98ed56dfb27f1de335a804d155  ./ros2-engineering-handbook/references/realtime.md
f73ae1a8f9b0c6e5836be98e55ea87f181d217706f35414b971c6c68f2744acd  ./ros2-engineering-handbook/references/testing.md
2bfe7cc9fde62c5b216f9a4f5c5d70d14abfbd119d81182ca303e6332b1b7428  ./ros2-engineering-handbook/references/tf2-urdf.md
f88adffb2d2f74822b15592c14c4c40bdd1e3bee62410620bb15ef13808d0bb6  ./ros2-engineering-handbook/references/workspace-build.md
de1ea788e79eeb9ef798c36921e23b07c87d36f45bdaca9c1b132bdf56abc5d6  ./ros2-engineering-handbook/scripts/create_package.py
7f904b8772fb712e7ee51ddeef963d788fc6ddf185dcc6052ecc6bf6f9fb223f  ./ros2-engineering-handbook/scripts/launch_validator.py
7c620b255112814abcfada19b9d82294cf4a23c9df5f41306c1afd083fabe46f  ./ros2-engineering-handbook/scripts/qos_checker.py
d51248f64dc08967a407d5dd70680309b9422157890ce538fcee18bfb230964c  ./ros2-engineering-handbook/scripts/rosbag2_qos_checker.py
```
