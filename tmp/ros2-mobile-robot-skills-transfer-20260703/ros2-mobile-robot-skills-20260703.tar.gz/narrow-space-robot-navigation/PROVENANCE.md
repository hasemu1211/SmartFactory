# Provenance — narrow-space-robot-navigation

- Skill name: `narrow-space-robot-navigation`
- Purpose: General guidance for tight-clearance mobile robot navigation, especially TurtleBot-class robots with lifts/forks/payloads.
- Source: Generated locally as a Codex/OMX-compatible skill using prior project research and general ROS/Nav2 robotics patterns.
- Third-party code: none.
- License: Apache License 2.0, provided in `LICENSE` for portable personal distribution.

## Scope

This skill is not tied to a single project. It can optionally read project-local documents when a repository contains them, but it must remain usable on another PC without that repository.

## Portability

This skill folder is self-contained and requires no local project checkout to load. Project-specific file references are optional examples only.
