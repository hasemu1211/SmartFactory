---
name: narrow-space-robot-navigation
description: Guidance for small mobile robots navigating tight or centimeter-clearance spaces, especially TurtleBot-class robots with lifts, forks, payloads, pallet handling, or constrained aisles. Use when the user asks about safe smooth narrow-space driving, Nav2 tuning for tight passages, localization/map accuracy, footprint/occupancy, collision monitor, velocity smoothing, DDS/compute load tradeoffs affecting driving, or camera/streaming load versus robot control. Do not use for generic ROS2, generic perception-only, generic web streaming, or unrelated robot tasks unless narrow-space navigation safety is part of the request.
---

# Narrow-Space Robot Navigation

Use this skill for **tight-clearance mobile robot navigation**: TurtleBot-class bases, small AMRs, lifts/forks, payloads, pallet-like handling, narrow aisles, and centimeter-level clearance where localization, footprint, costmaps, latency, and compute budget interact.

## Hard safety gate

- Do not issue or modify `/cmd_vel`, Nav2 actions, lifecycle transitions, ROS parameters, actuator commands, production services, or robot-side process launches unless the user explicitly asks for drive/bringup work and the action is non-destructive or separately authorized.
- For research, planning, and documentation tasks, stay read-only: inspect configs, logs, bags, docs, and runtime status; recommend experiments instead of mutating the robot.
- Treat vision/streaming as media/monitoring unless the user asks to connect it to drive decisions. Do not let a streaming optimization silently change robot control behavior.
- When in doubt, prefer safety, repeatability, and rollback over squeezing maximum speed through a narrow gap.

## When this skill is appropriate

Use it for questions such as:

- “A TurtleBot-like robot with a lift must drive through a space with only a few cm clearance.”
- “Which Nav2 parameters matter for narrow aisles?”
- “Should camera streaming stay on the robot or move to an offboard PC to protect control latency?”
- “How do footprint, inflation radius, collision monitor, velocity smoother, and AMCL covariance interact?”
- “How should I validate safe smooth drive in narrow spaces?”

Do not use it for:

- generic ROS2 package creation without tight-space driving context;
- generic object detection or camera streaming without navigation/load tradeoffs;
- manipulation-only planning where a mobile base is not navigating;
- unrelated web dashboard work.

## Core workflow

1. **Define the drive envelope.** Capture robot footprint including lift/fork/payload, rotation envelope, minimum aisle width, stopping distance, and acceptable clearance margin.
2. **Separate control-critical and non-critical compute.** Keep localization, controller, collision safety, and motor/control loops above camera/AI/media processes in priority. Offload video encoding/AI when robot CPU headroom is unknown.
3. **Localize before tuning speed.** Verify map resolution, AMCL/SLAM quality, TF freshness, odom drift, and covariance behavior before raising speed or reducing margins.
4. **Tune costmaps from geometry outward.** Start with measured footprint, obstacle sources, inflation radius, and cost scaling. Avoid “robot hugs walls” tuning without a measured safety argument.
5. **Control smoothness last.** Tune controller frequency, velocity limits, acceleration/deceleration, goal tolerance, rotate behavior, and velocity smoother after map/costmap correctness.
6. **Validate with bags and repeatable courses.** Use rosbag2, RViz costmaps, controller metrics, localization covariance, and p95/p99 latency/freeze/jitter observations.

## Reference router

Read only the needed file(s):

| Need | Read |
|---|---|
| Nav2/costmap/controller/collision-monitor checklist | `references/nav2-tight-clearance.md` |
| Localization, map quality, AMCL/SLAM, TF freshness | `references/localization-and-mapping.md` |
| Footprint, lift/fork/payload occupancy, safety gates | `references/footprint-and-safety.md` |
| Camera/AI/WebRTC load versus robot control budget | `references/compute-and-streaming-budget.md` |
| Field validation and measurement protocol | `references/validation-protocol.md` |

## Optional project-local context

If the current repository contains project-specific docs, read them as local evidence before making project recommendations. Examples of optional relative paths that may exist in a project:

- `docs/technical/narrow-space-ros2-nav2-drive-research-2026-07-03.md`
- `docs/technical/narrow-space-drive-validation-tuning-protocol-2026-07-03.md`
- `docs/technical/vision-streaming-efficiency-research-2026-07-03.md`
- scripts like `./scripts/vision/sf_lab.sh low-load` when the project defines them.

These are optional examples only; this skill must remain useful without those files.

## Good default stance

For TurtleBot-class hardware sharing CPU with Nav2/localization/control, prefer robot-side minimal camera bringup and offboard AI/overlay/video encode until measurements prove the robot can safely carry extra streaming/encoding load. Hardware H264 or UDP/RTP paths can be good experiments, but they need A/B validation under active navigation.
