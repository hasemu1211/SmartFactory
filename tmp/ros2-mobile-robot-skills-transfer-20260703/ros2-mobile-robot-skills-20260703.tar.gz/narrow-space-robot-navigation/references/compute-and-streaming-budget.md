# Compute and streaming budget for narrow-space driving

## Default stance

On TurtleBot-class hardware, prioritize localization, Nav2/controller, safety monitor, TF, odometry, and sensor drivers over video streaming, AI inference, and overlay generation.

A safe default is:

```text
Robot: camera bringup / sensor publication only
Offboard PC: AI, overlay, H264/WebRTC encode, dashboard streaming
```

This keeps robot CPU and thermal headroom for control-critical tasks.

## UDP is not the deciding factor

UDP is only a transport. The workload depends on the media pipeline:

| Path | Robot CPU risk | Notes |
|---|---:|---|
| Camera bringup + compressed image topic | Low to moderate | Simple and conservative if already used by the stack |
| Hardware H264 -> RTP/RTSP/MPEG-TS | Unknown until measured | Can be efficient, but adds process/network load on robot |
| Software H264 encode on robot | High | Avoid as default when Nav2/control share the CPU |
| MJPEG/JPEG streaming from robot | Moderate/high bandwidth | Simple but less efficient than inter-frame codecs |
| Raw/base64 image bridge | High | Avoid for tight-control systems |

## A/B test before promotion

Compare current conservative path against any robot-side H264/UDP experiment under active navigation:

- robot CPU, load average, memory, temperature/throttling;
- Nav2 controller frequency and missed deadlines;
- DDS discovery and topic latency;
- camera frame rate and drops;
- WebRTC browser dropped/frozen frames;
- glass-to-glass latency and visual quality;
- drive smoothness and min clearance.

Promote a heavier robot-side stream only if it improves latency/quality without degrading drive safety margins.
