# Footprint, lift/fork/payload occupancy, and safety gates

## Occupancy model

For tight navigation, the robot occupies more than the base footprint:

- base chassis;
- wheels/casters and rotation sweep;
- lift/fork/plate extension;
- payload overhang;
- sensor blind zones;
- stopping distance at current speed;
- localization uncertainty.

Treat the effective occupied region as:

```text
effective_footprint = physical_footprint
                    + dynamic_extension
                    + pose_uncertainty_margin
                    + stopping_margin
                    + policy_safety_margin
```

## Safety gates before increasing speed

- Footprint polygon matches the actual robot with lift/payload state.
- Collision monitor stop/slow polygons are visualized and tested.
- E-stop and software stop paths are verified.
- Nav2 recovery behavior cannot command unsafe rotation in a narrow passage.
- Localization covariance remains below the chosen margin during the route.
- CPU load and scheduling jitter do not delay control or sensor callbacks.

## Research vs execution boundary

For documentation/research tasks, recommend parameters and validation steps, but do not apply them to a live robot. Parameter mutation and motion tests need explicit user request and a clear rollback path.
