# Localization and mapping for tight spaces

## Why localization dominates narrow clearance

When clearance is measured in centimeters, a small pose error can be larger than the safety margin. Do not tune speed or inflation aggressively until localization quality is known.

## Checklist

1. **Map resolution and origin**
   - Use map resolution fine enough for the clearance being claimed.
   - Check wall thickness, obstacle edges, and map alignment against measured lab geometry.
   - Save maps with repeatable metadata and record how the map was built.

2. **AMCL / SLAM confidence**
   - Inspect covariance during straight motion, turning, and near-feature-poor corridors.
   - Verify laser scan alignment in RViz, not just robot pose on the map.
   - Re-localization jumps in narrow aisles should be treated as drive-blocking until understood.

3. **Odometry and TF**
   - Check TF tree continuity and age (`map -> odom -> base_link`).
   - Verify wheel odometry drift under payload/lift load.
   - Avoid using stale transforms for costmap obstacle insertion.

4. **Sensor placement**
   - Lift/fork/payload may occlude lidar or camera fields of view.
   - If front extension is not visible to sensors, footprint/collision monitor must account for it explicitly.

## Validation scenarios

- Drive centerline through the narrowest corridor at crawl speed.
- Repeat with lift raised/lowered and with/without payload if applicable.
- Replay rosbag2 into localization/costmap stack to reproduce drift and obstacle behavior.
- Record pose covariance, TF delay, scan matching quality, and min clearance.
