# Nav2 tight-clearance checklist

## Tune in this order

1. **Geometry first**
   - Measure base footprint, lift/fork extension, payload overhang, caster sweep, and rotation envelope.
   - Use a polygon footprint when the lift/payload changes the occupied space; do not approximate with a radius if the clearance is centimeter-level.
   - Ensure `robot_state_publisher` / TF includes any fixed lift/camera frames used for safety reasoning.

2. **Costmap correctness**
   - Confirm obstacle sources appear in RViz local/global costmaps at the right frame and timestamp.
   - Start with conservative obstacle marking/clearing and verify no ghost obstacles remain in narrow passages.
   - Tune `inflation_radius` from measured footprint + safety margin.
   - Tune `cost_scaling_factor` after radius. Higher scaling makes inflation cost drop faster, which can make the robot drive closer to walls.

3. **Planner/controller**
   - Prefer conservative max velocity/acceleration until localization covariance and costmap stability are proven.
   - Tight spaces often fail because rotate/spin recovery needs more room than the aisle gives; consider backup/wait/clear-costmap behavior before spin-heavy recovery.
   - Use `velocity_smoother` when command discontinuities cause jerk, oscillation, or lift/payload sway.

4. **Collision monitor**
   - Add a stop/slowdown polygon that matches the true front extension of lift/fork/payload.
   - Keep collision monitor independent from local planner assumptions; it is the last software safety layer.
   - Validate stop distance at the slowest and fastest planned operating speeds.

## Common failure patterns

| Symptom | Likely cause | First checks |
|---|---|---|
| Robot refuses narrow gap | Inflation too wide, footprint too large, obstacle layer stale | RViz costmap, footprint polygon, `inflation_radius` |
| Robot hugs walls | Cost decays too fast, controller too aggressive | `cost_scaling_factor`, controller critics, speed limits |
| Oscillation near goal | Goal tolerance too tight, controller frequency/speed mismatch | `xy_goal_tolerance`, `yaw_goal_tolerance`, controller frequency |
| Recovery spin fails | Not enough rotation space | BT recovery order, backup before spin, smaller spin distance |
| Sudden stops | Collision monitor polygon too large or sensor noise | Collision monitor visualization, sensor filtering |

## Metrics to capture

- local/global costmap screenshots or bags;
- command velocity (`cmd_vel`) and odom velocity;
- controller error and recovery count;
- localization covariance and TF age;
- minimum measured clearance at several points in the path.
