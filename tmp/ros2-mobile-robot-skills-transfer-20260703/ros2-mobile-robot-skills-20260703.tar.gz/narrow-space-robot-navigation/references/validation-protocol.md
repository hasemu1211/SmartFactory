# Tight-clearance validation protocol

## 1. Preflight

- Record robot physical dimensions and footprint with lift/payload states.
- Save current Nav2/costmap/controller/collision-monitor parameters.
- Verify map, TF, localization, odom, lidar/camera topics, and safety stop.
- Define rollback commands and a stop condition.

## 2. Static validation

- RViz: footprint overlays match actual footprint.
- RViz: global/local costmaps show narrow corridor accurately.
- Verify inflation radius and collision monitor polygons visually.
- Check CPU governor/thermal state if the robot is resource constrained.

## 3. Slow live pass

- Run at crawl speed.
- Record rosbag2: `/tf`, `/tf_static`, `/odom`, scans, costmaps if available, `/cmd_vel`, diagnostics, localization pose/covariance.
- Observe min clearance and recovery behaviors.

## 4. Incremental tuning

Change one class of setting at a time:

1. footprint/costmap geometry;
2. inflation/cost scaling;
3. controller speed/accel/tolerance;
4. recovery behavior;
5. compute/streaming load.

## 5. Acceptance evidence

- Repeatable route completion without wall contact or unsafe recovery.
- No unexplained localization jumps.
- Controller and safety callbacks maintain expected cadence.
- CPU/thermal/network headroom remains acceptable.
- Video/AI/streaming changes do not degrade navigation metrics.
