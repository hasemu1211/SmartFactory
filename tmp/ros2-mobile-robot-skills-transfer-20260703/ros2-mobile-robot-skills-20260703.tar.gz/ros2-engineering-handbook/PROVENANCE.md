# Provenance — ros2-engineering-handbook

- Skill name: `ros2-engineering-handbook`
- Purpose: Codex/OMX-compatible deep ROS 2 engineering handbook and second-opinion reference.
- Upstream source: `https://github.com/dbwls99706/ros2-engineering-skills`
- Upstream commit reviewed/imported: `3706f65`
- Upstream license: Apache License 2.0, preserved in `LICENSE.upstream`.
- Compatibility target: Codex/OMX skills with `SKILL.md` frontmatter limited to `name` and `description`.

## Imported upstream subset

References imported into `references/`:

- `communication.md`
- `navigation.md`
- `realtime.md`
- `perception.md`
- `nodes-executors.md`
- `debugging.md`
- `deployment.md`
- `testing.md`
- `workspace-build.md`
- `launch-system.md`
- `lifecycle-components.md`
- `hardware-interface.md`
- `tf2-urdf.md`
- `message-types.md`

Scripts imported into `scripts/`:

- `qos_checker.py`
- `launch_validator.py`
- `rosbag2_qos_checker.py`
- `create_package.py`

## Local adaptations

- Rewrote `SKILL.md` to use Codex-compatible metadata and a narrower trigger policy.
- Removed Claude-plugin-only frontmatter keys, hooks, and eval metadata from the installed skill.
- Positioned this skill as a deep-reference / second-opinion handbook that complements, rather than replaces, existing ROS skills.
- Did not copy Claude plugin hook scripts as active hooks.

## Portability

This skill folder is self-contained. It does not require the upstream clone after installation.
