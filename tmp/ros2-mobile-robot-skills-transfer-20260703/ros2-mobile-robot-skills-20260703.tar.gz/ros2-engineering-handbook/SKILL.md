---
name: ros2-engineering-handbook
description: Deep ROS 2 engineering handbook and cross-domain reference for Codex/OMX. Use for ROS2 robotics tasks where correctness, safety, latency, deployment quality, or architectural tradeoffs may depend on DDS/QoS, executors, lifecycle, launch, Nav2, realtime behavior, ros2_control, tf/URDF, testing, deployment, perception, or multi-node integration. Use alongside narrower installed skills when a task spans multiple ROS2 domains, involves production-grade review, performance/debugging, field robot reliability, or unclear tradeoffs. Do not use for trivial single-file edits or routine package scaffolding when a narrower skill fully covers the task.
---

# ROS 2 Engineering Handbook

Use this skill as a **deep cross-domain ROS 2 engineering reference layer**. It is intentionally additive: use it with the narrower installed ROS and robotics skills when a task needs broader engineering judgment.

## Precedence and trigger policy

1. For routine single-domain ROS2 work, prefer the existing narrower installed skill first, such as:
   - `ros2-development`
   - `robot-perception`
   - `robot-bringup`
   - `robotics-testing`
   - `docker-ros2-development`
   - `ros2-web-integration`
   - `robotics-security`
2. Use this handbook alongside the narrower skill when correctness, safety, latency, deployment quality, field reliability, or architectural tradeoffs depend on multiple ROS2 domains.
3. Enter this handbook proactively for complex debugging/performance work involving DDS/QoS, executors, lifecycle, launch, Nav2, realtime behavior, ros2_control, tf/URDF, testing, deployment, perception, or multi-node integration.
4. Also use it when the user explicitly asks for deeper domain knowledge, production-grade reference, a second opinion, migration/distro nuance, or cross-cutting tradeoffs.
5. Do not load every reference. Select the 1-2 files that match the current question.
6. Check official ROS/Nav2/DDS/vendor docs or live project evidence when the answer depends on current versions, behavior, hardware, or safety.

## Reference router

Read only the relevant file(s):

| Need | Read |
|---|---|
| DDS, QoS, topics/services/actions, deadlines/lifespans, large messages | `references/communication.md` |
| Nav2, SLAM, AMCL, costmaps, planners/controllers, recovery, collision monitor | `references/navigation.md` |
| Realtime, jitter, CPU governor, PREEMPT_RT, callback groups, DDS RT tuning | `references/realtime.md` |
| Cameras, image_transport, cv_bridge, point clouds, sensor fusion, ML inference | `references/perception.md` |
| rclcpp/rclpy nodes, executors, callback groups, threading | `references/nodes-executors.md` |
| ros2 doctor, tracing, profiling, rosbag2, CLI debugging | `references/debugging.md` |
| Docker/cross-compile/deployment/fleet packaging | `references/deployment.md` |
| gtest/pytest/launch_testing/CI strategies | `references/testing.md` |
| colcon, ament, package.xml, CMake, overlays | `references/workspace-build.md` |
| Python launch, lifecycle launch events, launch validation | `references/launch-system.md` |
| Lifecycle nodes, composition, component containers | `references/lifecycle-components.md` |
| ros2_control hardware interfaces/controllers | `references/hardware-interface.md` |
| tf2, URDF, xacro, robot_state_publisher | `references/tf2-urdf.md` |
| Message units, covariance, frame conventions, diagnostics | `references/message-types.md` |

## Helper scripts

The copied scripts are optional deterministic helpers. Run them from this skill folder or copy them into a project as needed.

- `scripts/qos_checker.py` — check Request-vs-Offered QoS compatibility.
- `scripts/rosbag2_qos_checker.py` — check rosbag2 playback QoS compatibility from `metadata.yaml`.
- `scripts/launch_validator.py` — static analysis for Python ROS2 launch files.
- `scripts/create_package.py` — scaffold ROS2 packages using the upstream conventions.

Before relying on a script in a new environment, run `python3 -m py_compile scripts/*.py` and the script `--help` command.

## Distribution and provenance

- Imported material comes from `dbwls99706/ros2-engineering-skills` and is documented in `PROVENANCE.md`.
- Upstream Apache-2.0 license text is preserved in `LICENSE.upstream`.
- This skill is self-contained and should remain usable after copying the folder to another machine.
